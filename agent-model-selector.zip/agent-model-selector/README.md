# Edge AI Model Selector — Agent 2 of the Edge AI Copilot Suite

## What this agent does

Enter a task (e.g. "keyword-spotting"), optionally cap the model size, click **Search**.
It queries the **live Hugging Face Hub API** for real candidate models -- real download
counts, real likes, real file sizes summed from actual repo metadata -- ranks them with a
reproducible formula, and shows a table, a bar chart, and a short summary of the top pick.

**This is a search-and-report form, not a chatbot.** There's one query, one complete
ranked result -- no conversation to have. The form UI also makes the two size fields
(task, size limit) explicit and reusable, instead of buried in a sentence you'd have to
re-type each time.

## Why it's built this way (architecture)

```
Task + size limit
    |
    v
search_models_for_task()  <-- LIVE network call to huggingface.co (list_models, then
    |                          model_info per candidate). Real data, not memory.
    v
popularity_score = f(downloads, likes)   <-- plain arithmetic, computed after the real
    |                                         data comes back. Deterministic: same live
    |                                         data -> same ranking, every time.
    v
Ranked table + bar chart   <-- shown directly
    |
    v
summarize()  <-- the ONLY place Gemini is called. Given the already-ranked table, it
    |             writes a short summary. Told explicitly not to re-rank or invent models.
    v
Summary panel
```

## The ranking formula (exact)

```
popularity_score = min(100, downloads^0.15 * 8 + likes^0.2 * 3)
```

Both terms use a fractional power (log-like compression) so one viral model with millions
of downloads doesn't make every other candidate look like zero -- it flattens the curve
while still rewarding real popularity. Downloads are weighted more heavily than likes
(coefficient 8 vs 3) since download count is a stronger signal of actual production use.

If `max_size_mb` is set, any candidate whose real total file size (summed from the Hub's
file metadata) exceeds it is dropped before ranking -- this filtering happens in code, not
by asking the LLM to eyeball sizes.

## What's in this folder

| File | Purpose |
|---|---|
| `app.py` | Live Hub search, deterministic ranking, Gemini summary call, Gradio dashboard UI |
| `requirements.txt` | Python dependencies |
| `Dockerfile` | Container build instructions |
| `README.md` | This file |

## UI walkthrough

- **Task textbox** — free text, matched against the Hub's search index (not a fixed
  dropdown, since the Hub has far too many task variants to enumerate).
- **Max size slider** — 0 means no limit; drag it up to filter out anything over that
  real, computed size.
- **Search button** — triggers a live Hub query plus the ranking calculation.
- **Ranked candidates table** — model ID, pipeline tag, real download/like counts,
  estimated size, and the computed popularity score, sorted highest first.
- **Popularity bar chart** — the same scores, visually, one bar per candidate model.
- **Summary panel** — Gemini's short plain-language take on the top result.

## Prerequisites

1. **Docker**, installed and running.
2. **A free Gemini API key** from [aistudio.google.com](https://aistudio.google.com) — no
   card required.
3. **The container needs outbound internet access at runtime** — every search is a live
   call to `huggingface.co`. No Hugging Face account or token is required for public model
   search.

## Steps to run it

```bash
cd agent-model-selector
docker build -t edge-model-selector .
docker run -p 7861:7861 -e GEMINI_API_KEY=your_key_here edge-model-selector
```

Open [http://localhost:7861](http://localhost:7861). Try task `image-classification` with
a 50MB size limit, or `automatic-speech-recognition` with no limit.

Stop with `Ctrl+C`, or `docker stop <container_id>`.

## Publishing to Docker Hub

```bash
docker login
docker tag edge-model-selector your-dockerhub-username/edge-model-selector:latest
docker push your-dockerhub-username/edge-model-selector:latest
```

Others run it with:
```bash
docker run -p 7861:7861 -e GEMINI_API_KEY=their_key your-dockerhub-username/edge-model-selector
```

## Notes / limitations

- **Speed:** each search can trigger several live API calls (one `list_models` plus one
  `model_info` per candidate), so expect a few seconds' latency -- the honest cost of real
  live data over a static table.
- **Size isn't always available.** Some Hub repos don't expose clean file-size metadata;
  those rows show `estimated_size_mb: None` rather than a fabricated number, and are
  excluded from a size-limited search since their fit can't be confirmed.
- **Rate limits:** anonymous Hub access has a request-rate limit. For heavy demo use, add
  `-e HF_TOKEN=your_hf_token` to `docker run` for a higher limit -- not required for normal
  use.
- **This agent's live Hub network calls still weren't tested end-to-end** (the sandbox that
  built it can't reach `huggingface.co`) — but the fix above was verified against the actual
  installed `huggingface_hub` 1.x library (confirmed via its real function signature, not
  guessed), so the `TypeError` you hit is resolved. Do one real smoke test before a live demo
  to confirm the network path itself works in your environment.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `TypeError: HfApi.list_models() got an unexpected keyword argument 'direction'` | `huggingface_hub` 1.x removed the `direction` kwarg (confirmed: the library jumped to a major version that also dropped it from `sort` behavior) | Already fixed in this version of `app.py` — it no longer passes `sort`/`direction` to `list_models()` at all; results are fetched unsorted and ranked in plain Python instead, so this works regardless of installed SDK version |
| `RuntimeError: GEMINI_API_KEY is not set` | Forgot `-e GEMINI_API_KEY=...` | Add the flag with your real key |
| Empty results table | No internet access from inside the container, task query too narrow, or Hub rate limit hit | Check outbound network access; try a broader task string; add `HF_TOKEN` |
| Very slow response | Many candidates each needing a `model_info` call | Lower `top_k` in `search_models_for_task` inside `app.py`, rebuild |
| `404 NOT_FOUND` model error in the summary | Gemini deprecated `gemini-3.6-flash` | Check [aistudio.google.com](https://aistudio.google.com) for the current model ID, update `summarize()`, rebuild |
| Port conflict | 7861 already in use | Run with `-p 8081:7861`, open `localhost:8081` |

## Pairing with Agent 1

Run Agent 1 first to find out *what task* is feasible on your device, then feed that task
into this agent's textbox (with a size limit informed by Agent 1's device RAM) to go from
"what can I run" to "which exact model should I use."

## Why not a chatbot

Same reasoning as Agent 1: one query produces one complete, structured result. A form
makes the two real inputs (task, size limit) explicit and easy to adjust and re-run, which
a sentence typed into a chat box doesn't offer as cleanly.
