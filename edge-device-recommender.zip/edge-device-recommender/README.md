# Edge AI Device Recommender — Agent 1 of the Edge AI Copilot Suite

## What this agent does

Pick a device from a dropdown (or type a new one), click **Analyze**. It computes a
feasibility score for every known edge AI task on that device — using real arithmetic
over real specs, not an LLM's opinion — and shows you a table, a bar chart, and a short
plain-language explanation of the result.

**This is a dashboard, not a chatbot.** There's no back-and-forth conversation to have —
one device in, one complete report out. That's a deliberate design choice: the useful part
of this agent is a reproducible computation, and a form-and-report UI makes that obvious
in a way a chat window doesn't.

## Why it's built this way (architecture)

Most "AI agent" demos put an LLM in charge of every decision, including ones that don't
need judgment — like "does a 76.8MB model fit in 1024MB of RAM." That's slower, costs a
model call for something arithmetic could answer instantly, and gives you a different
answer if you ask twice.

This agent splits the work instead:

```
Device name
    |
    v
score_feasibility()  <-- plain Python, pandas, arithmetic. No LLM involved.
    |                     Same device in -> same scores out, every single time.
    v
Score table + bar chart   <-- shown directly, straight from the computation
    |
    v
explain()  <-- the ONLY place Gemini is called. Given the already-computed scores,
    |           it writes 3-4 sentences of plain-language narrative. It is explicitly
    |           told not to recompute or contradict the numbers it's shown.
    v
Explanation panel
```

The LLM's role is narrow on purpose: turn a table into a sentence a human enjoys reading.
It never decides what's feasible.

## The scoring formula (exact)

For each task, the smallest reference model for that task is used as the fit baseline.
Three components, weighted and summed to a 0-100 score:

| Component | Weight | Logic |
|---|---|---|
| RAM headroom | 50% | Model should use well under available RAM, not just barely fit. Ratio of model size to device RAM; under 5% usage scores 100, scaling down as the ratio grows. |
| Accelerator presence | 30% | A device with any NPU/GPU/TPU/DSP scores 100. A CPU-only device scores 70 if the model is under 1MB (still fine), 30 otherwise (large model, no acceleration, likely too slow). |
| Power budget | 20% | Flat penalty only for very tight (<1W) power budgets paired with non-trivial (>=0.5MB) models. |

`overall = 0.5*ram_score + 0.3*accel_score + 0.2*power_score`, rounded to the nearest
integer. Verdict thresholds: 75+ = highly feasible, 40-74 = marginal, under 40 = not
feasible.

This formula is a reasonable heuristic, not a certified benchmark — it's meant to
differentiate devices sensibly (and it does: see the Coral Dev Board vs. Arduino example
below), not to replace real hardware profiling. Treat the score as a starting point for
investigation, not a guarantee.

## What's in this folder

| File | Purpose |
|---|---|
| `app.py` | Dataset, deterministic scoring, Gemini explanation call, Gradio dashboard UI |
| `requirements.txt` | Python dependencies |
| `Dockerfile` | Container build instructions |
| `README.md` | This file |

## UI walkthrough

- **Device dropdown** — pick from 14 known devices, or type any name (free text is
  allowed; if it's not in the table, the app tells you plainly rather than guessing specs
  for an unknown device).
- **Analyze button** — triggers the full pipeline (score, then explain).
- **Feasibility scores table** — one row per task: reference model, its size, the
  computed score, and the verdict.
- **Device specs panel** — the exact RAM/accelerator/power numbers used in the
  calculation, so you can check the math yourself.
- **Bar chart** — the same scores, visually, colored by verdict.
- **Explanation panel** — Gemini's plain-language summary of the table above it.

The dashboard loads with Raspberry Pi 4 pre-analyzed on startup, so there's something to
look at immediately rather than a blank screen.

## Prerequisites

1. **Docker**, installed and running.
2. **A free Gemini API key** from [aistudio.google.com](https://aistudio.google.com) — sign
   in with any Google account, "Get API key -> Create API key in new project." No credit
   card required.

## Steps to run it

```bash
cd edge-device-recommender
docker build -t edge-device-recommender .
docker run -p 7860:7860 -e GEMINI_API_KEY=your_key_here edge-device-recommender
```

Open [http://localhost:7860](http://localhost:7860). Pick a device, click Analyze.

Stop with `Ctrl+C` in the terminal, or `docker stop <container_id>` (find the ID with
`docker ps`).

## Publishing to Docker Hub

```bash
docker login
docker tag edge-device-recommender your-dockerhub-username/edge-device-recommender:latest
docker push your-dockerhub-username/edge-device-recommender:latest
```

Anyone can then run it with just:
```bash
docker run -p 7860:7860 -e GEMINI_API_KEY=their_own_key your-dockerhub-username/edge-device-recommender
```

## Extending the dataset

Add rows directly to the `devices` or `benchmarks` DataFrames near the top of `app.py`,
then rebuild the image. No other code changes needed — the scoring function and UI both
read from these tables automatically. Good sources for more real rows:

- [MLPerf Tiny](https://github.com/mlcommons/tiny) — reference tasks/models
- [MLPerf Tiny results](https://github.com/mlcommons/tiny_results_v1.3) — real per-device
  latency numbers (this table's `latency_ms` column is currently all `None` — filling
  these in from here is the single highest-value improvement you can make)
- [nn-Meter](https://github.com/microsoft/nn-Meter) — 26k-model latency dataset (archived
  but the dataset still works)
- Vendor datasheets for new device rows

## Known limitations

- **No latency data.** Every `latency_ms` is `None`. The score currently reflects
  fit/power/acceleration, not speed. It won't fabricate a latency number.
- **Small dataset.** 14 devices, 7 benchmark rows — enough for a hackathon demo, not a
  production tool.
- **Heuristic scoring, not certified benchmarks.** The formula is a reasonable
  approximation, explained in full above so you (or a judge) can inspect exactly how a
  number was produced — that transparency is the point, not a claim of precision.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `RuntimeError: GEMINI_API_KEY is not set` | Forgot `-e GEMINI_API_KEY=...` in `docker run` | Add the flag with your real key |
| `docker: ... port is already allocated` | Something else is using port 7860 | Run with `-p 8080:7860`, open `localhost:8080` instead |
| `404 NOT_FOUND` model error | Gemini deprecated the model ID (`gemini-3.6-flash`) used in `app.py` | Check [aistudio.google.com](https://aistudio.google.com) for the current model name, update the `model=` string in `explain()`, rebuild |
| Explanation panel shows an error instead of text | Network issue reaching the Gemini API from inside the container, or an invalid key | Check the container has outbound internet access; verify the key at aistudio.google.com |
| Score table looks empty | Typed device name doesn't match anything in the table (even by substring) | Use the dropdown, or check spelling against the "Known devices" list shown in the explanation panel |

## Why not a chatbot

A chat interface implies a conversation with give-and-take. This agent doesn't have one —
every query is "score this device," full stop. A form that produces a complete report in
one click is faster to use, easier to demo, and makes the deterministic-vs-LLM split in
the architecture visually obvious (the table and chart appear instantly; only the
explanation text involves an API call).
