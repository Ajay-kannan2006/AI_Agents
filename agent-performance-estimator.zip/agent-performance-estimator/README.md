# Edge AI Performance Estimator — Agent 5 of the Edge AI Copilot Suite

## What this agent does

Upload a real `.onnx` model, click **Estimate Performance**. Parameter count is exact — summed
directly from the model's real weight tensors. FLOPs are computed from real operator shapes
using ONNX's own shape inference engine, not guessed. Those real numbers then feed a heuristic
per-device-class latency estimate across all 14 devices from the suite's shared device dataset,
shown as a sorted bar chart.

**Verified correct before shipping, not just syntactically valid:** tested against a model with
a known, hand-calculable answer (a single 256x256 Gemm layer). Expected params: 65,792. Computed:
65,792. Expected FLOPs (2×M×N×K): 131,072. Computed: 131,072. Exact match — this isn't an
approximation of the parameter count, it's the real count.

**Its own color theme** — cyan/teal (`gr.themes.Soft(primary_hue="cyan", secondary_hue="teal")`),
distinct from Agent 4's orange/amber and the default themes on Agents 1-3.

## Why it's built this way (architecture)

```
Uploaded .onnx file
    |
    v
onnx.load() + checker.check_model()   <-- real parsing/validation
    |
    v
count_params()   <-- sums real initializer tensor sizes. Exact, not estimated.
    |
    v
shape_inference.infer_shapes()   <-- ONNX's own shape inference, resolves real tensor shapes
    |                                 wherever the graph allows it statically
    v
estimate_flops()   <-- computes real FLOPs for Conv/Gemm/MatMul (the ops that dominate compute
    |                   in nearly every edge model) using real weight shapes x real inferred
    |                   output shapes. Ops whose shapes can't be resolved are listed as
    |                   "unknown", excluded from the total rather than guessed.
    v
estimate_latency_per_device()   <-- deterministic: FLOPs / (heuristic effective GFLOPS for the
    |                                device's compute class). Same FLOPs -> same table, always.
    v
Latency chart across all 14 devices, sorted fastest to slowest
    |
    v
explain()  <-- the ONLY place Gemini is called. Given the real params/FLOPs/latency numbers
    |           already computed, it writes a short summary. Told explicitly not to invent or
    |           contradict what it's shown, and to flag this as heuristic, not a benchmark.
    v
Summary panel
```

## What's actually measured vs. estimated (read this before trusting a number)

| Quantity | How it's produced | Confidence |
|---|---|---|
| Parameter count | Exact sum of real weight tensor sizes | Exact |
| FLOPs (Conv/Gemm/MatMul) | Real weight shapes x real inferred output shapes, standard FLOPs formula | Good approximation for the covered ops |
| FLOPs (other op types) | Not computed — excluded, listed as "unknown ops" | Not included, not guessed |
| Latency per device | FLOPs ÷ a heuristic effective-GFLOPS figure per compute class (rough order-of-magnitude assumption, not a benchmark) | **Heuristic only** — a starting point for comparison, not a real measurement |

The `EFFECTIVE_GFLOPS` table near the top of `app.py` is the honest weak link in this pipeline:
those numbers are rough real-world-achievable-throughput assumptions per compute class, not
measured benchmarks. Treat the latency chart as "which devices are in the right ballpark,
relatively," not "this model will run in exactly N milliseconds." Real profiling on actual
hardware is the next step once this narrows down candidates.

## What's in this folder

| File | Purpose |
|---|---|
| `app.py` | Params/FLOPs computation, shape inference, heuristic latency model, Gemini summary, Gradio UI |
| `requirements.txt` | Python dependencies |
| `Dockerfile` | Container build instructions |
| `README.md` | This file |

## UI walkthrough

- **File upload** — accepts `.onnx` files only.
- **Estimate Performance button** — triggers real parsing, param counting, shape inference,
  FLOPs estimation, and the per-device latency calculation.
- **Model stats panel** — real parameter count and estimated FLOPs (in millions), plus a note if
  any operators were excluded from the FLOPs total.
- **Latency chart** — all 14 devices, sorted fastest to slowest, colored by compute class.
- **Summary panel** — Gemini's short take: the real numbers, the fastest/slowest device by name,
  and a reminder that this is a heuristic estimate.

## Prerequisites

1. **Docker**, installed and running.
2. **A free Gemini API key** from [aistudio.google.com](https://aistudio.google.com) — no card
   required.
3. **A real `.onnx` model file** to test with — reuse one from Agent 3 or 4.

## Steps to run it

```bash
cd agent-performance-estimator
docker build -t edge-performance-estimator .
docker run -p 7864:7864 -e GEMINI_API_KEY=your_key_here edge-performance-estimator
```

Open [http://localhost:7864](http://localhost:7864), upload an `.onnx` file, click Estimate
Performance.

Stop with `Ctrl+C`, or `docker stop <container_id>`.

## Publishing to Docker Hub

```bash
docker login
docker tag edge-performance-estimator your-dockerhub-username/edge-performance-estimator:latest
docker push your-dockerhub-username/edge-performance-estimator:latest
```

Others run it with:
```bash
docker run -p 7864:7864 -e GEMINI_API_KEY=their_key your-dockerhub-username/edge-performance-estimator
```

## Improving the estimate

The single highest-value improvement: replace `EFFECTIVE_GFLOPS`'s heuristic numbers with real
measured throughput from the MLPerf Tiny results repos (the same source Agent 1 points to for
its still-empty `latency_ms` column) — once both agents share real measured numbers instead of
heuristics, the whole suite's latency story gets meaningfully more trustworthy.

Also worth adding: FLOPs coverage for more operator types (currently only Conv/Gemm/MatMul are
counted — depthwise-separable patterns, attention/LayerNorm-heavy models, and RNN cells will
undercount today).

## Known limitations

- **Latency is heuristic, not measured** — see the table above. Say this explicitly if
  presenting to judges; don't let the chart imply more precision than it has.
- **FLOPs only cover Conv/Gemm/MatMul.** Models dominated by other operators will show a lower
  FLOPs count than their real compute cost, with the gap listed as "unknown ops" in the panel.
- **Static shapes required.** Models with fully dynamic input shapes (no fixed batch/spatial
  dims anywhere) may have most or all ops fall into "unknown" since shape inference can't
  resolve them without a concrete input.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `RuntimeError: GEMINI_API_KEY is not set` | Forgot `-e GEMINI_API_KEY=...` | Add the flag with your real key |
| "Could not load this as a valid ONNX model" | File isn't valid/corrupted ONNX | Verify it loads with `onnx.load()` locally first |
| FLOPs shows as very low / most ops "unknown" | Model has dynamic input shapes shape inference can't resolve | Export the model with a fixed input shape (no dynamic axes), rebuild |
| `404 NOT_FOUND` model error in the summary | Gemini deprecated `gemini-3.6-flash` | Check [aistudio.google.com](https://aistudio.google.com) for the current model ID, update `explain()`, rebuild |
| Port conflict | 7864 already in use | Run with `-p 8084:7864`, open `localhost:8084` |

## Pairing with Agents 1-4

Run this after Agent 3 (Compression Advisor) to see how much the latency estimate improves
post-quantization, and cross-check the "fastest device" result here against Agent 1's
feasibility scores for the same device — they're computed independently and should broadly
agree.

## Why not a chatbot

One file in, one computed report out. The bar chart across all 14 devices at once is the whole
point — a chat answer would have to either dump a wall of numbers in prose or make you ask
device-by-device, both worse than seeing the comparison at a glance.
