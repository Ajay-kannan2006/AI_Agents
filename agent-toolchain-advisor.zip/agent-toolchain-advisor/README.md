# Edge AI Toolchain Advisor — Agent 4 of the Edge AI Copilot Suite

## What this agent does

Upload a real `.onnx` model, pick which deployment frameworks to check (ONNX Runtime,
TensorRT, TFLite, OpenVINO), click **Check Compatibility**. Every operator actually present in
your model's graph is looked up against a curated real framework op-support reference, giving
you a computed compatibility percentage per framework and a full per-operator breakdown — not
an LLM's guess about whether your model will convert cleanly.

**This is an upload-and-report tool, not a chatbot.** One file in, one compatibility report out.

**Visually distinct from the other agents on purpose** — this one uses an orange/amber theme
(`gr.themes.Soft(primary_hue="orange", secondary_hue="amber")`) so it's immediately
recognizable apart from Agents 1-3 when you're flipping between running containers on demo day.

## Why it's built this way (architecture)

```
Uploaded .onnx file
    |
    v
onnx.load() + checker.check_model()   <-- real parsing/validation
    |
    v
Real operator-type counts, parsed directly from the model graph
    |
    v
COMPAT_TABLE lookup   <-- curated reference of real framework op-support characteristics.
    |                      Ops not in the table are marked "unknown", never assumed supported.
    v
compatibility_pct = weighted sum (yes=1.0, partial=0.5, no/unknown=0.0) / total ops
    |                <-- plain arithmetic. Same model + same frameworks -> same score, always.
    v
Score chart + detailed per-op table   <-- shown directly, straight from the computation
    |
    v
explain()  <-- the ONLY place Gemini is called. Given the already-computed scores and the list
    |           of flagged-unsupported ops, it writes a short recommendation. Told explicitly
    |           not to invent or contradict the numbers it's shown.
    v
Recommendation panel
```

## The compatibility reference (and its honest limits)

`COMPAT_TABLE` in `app.py` covers ~38 common ONNX operator types across four frameworks, each
marked `yes` / `partial` / `no` based on well-established general framework characteristics
(e.g. TensorRT historically needing plugins for `NonMaxSuppression`; TFLite conversion being
lossy for `Gemm`/`MatMul` since TFLite favors its own `FullyConnected` op; `Resize`/`Upsample`
mode-dependent support across the board).

**This is a curated best-effort reference, not a live per-version check.** Framework op support
changes between releases — always confirm against your exact target framework's current
documentation before a final deployment decision. Any operator not in the table is marked
"❔ not in reference table" rather than assumed to work, so the score never overstates
confidence for operators this agent doesn't actually know about.

## What's in this folder

| File | Purpose |
|---|---|
| `app.py` | Curated compat reference, real ONNX parsing, scoring, Gemini recommendation, Gradio UI |
| `requirements.txt` | Python dependencies |
| `Dockerfile` | Container build instructions |
| `README.md` | This file |

## UI walkthrough

- **File upload** — accepts `.onnx` files only.
- **Framework checkboxes** — pick any subset of ONNX Runtime / TensorRT / TFLite / OpenVINO;
  all four are checked by default.
- **Check Compatibility button** — triggers real parsing, lookup, and scoring.
- **Compatibility score chart** — one bar per selected framework, 0-100%.
- **Per-operator table** — every operator in your model, its count, and its status
  (✅ supported / ⚠️ partial-conditional / ❌ unsupported / ❔ not in reference table) per
  framework.
- **Recommendation panel** — Gemini's short take on which framework(s) fit best and which ops
  are the real risk, grounded in the table above it.

## Prerequisites

1. **Docker**, installed and running.
2. **A free Gemini API key** from [aistudio.google.com](https://aistudio.google.com) — no card
   required.
3. **A real `.onnx` model file** to test with — reuse one from the Compression Advisor agent, or
   export any small model with `torch.onnx.export()`.

## Steps to run it

```bash
cd agent-toolchain-advisor
docker build -t edge-toolchain-advisor .
docker run -p 7863:7863 -e GEMINI_API_KEY=your_key_here edge-toolchain-advisor
```

Open [http://localhost:7863](http://localhost:7863), upload an `.onnx` file, click Check
Compatibility.

Stop with `Ctrl+C`, or `docker stop <container_id>`.

## Publishing to Docker Hub

```bash
docker login
docker tag edge-toolchain-advisor your-dockerhub-username/edge-toolchain-advisor:latest
docker push your-dockerhub-username/edge-toolchain-advisor:latest
```

Others run it with:
```bash
docker run -p 7863:7863 -e GEMINI_API_KEY=their_key your-dockerhub-username/edge-toolchain-advisor
```

## Extending the compatibility reference

Add or correct rows in the `COMPAT_TABLE` dictionary near the top of `app.py` — no other code
changes needed. Good sources for verifying entries: each framework's official supported-ops
documentation (ONNX Runtime's execution provider docs, TensorRT's ONNX parser support matrix,
the TFLite converter's op compatibility guide, OpenVINO's ONNX frontend docs).

## Known limitations

- **Static reference table**, not a live per-version check — see the honesty note above.
- **~38 operators covered.** A model using an operator outside this list will show
  "❔ not in reference table" for it rather than a real answer — expand `COMPAT_TABLE` if you
  hit this often.
- **Doesn't attempt an actual conversion.** This predicts compatibility from operator names; it
  doesn't run the real TFLite/TensorRT converter, which could surface additional issues (shape
  constraints, custom op registration, etc.) beyond operator-name support.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `RuntimeError: GEMINI_API_KEY is not set` | Forgot `-e GEMINI_API_KEY=...` | Add the flag with your real key |
| "Could not load this as a valid ONNX model" | File isn't valid/corrupted ONNX | Verify it loads with `onnx.load()` locally first |
| Many ops show "❔ not in reference table" | Your model uses operators outside the curated 38 | Add them to `COMPAT_TABLE` in `app.py`, citing the framework's real docs, rebuild |
| `404 NOT_FOUND` model error in the recommendation | Gemini deprecated `gemini-3.6-flash` | Check [aistudio.google.com](https://aistudio.google.com) for the current model ID, update `explain()`, rebuild |
| Port conflict | 7863 already in use | Run with `-p 8083:7863`, open `localhost:8083` |
| Theme doesn't apply / warning about `theme` argument | Installed Gradio version predates 6.0's `theme`-on-`launch()` change | `app.py` already handles both cases with a try/except fallback — no action needed |

## Pairing with Agents 1-3

Run this after Agent 3 (Compression Advisor) on your quantized model — quantization can
introduce operators (like `DynamicQuantizeLinear`, `QLinearConv`) that behave differently across
frameworks, so it's worth re-checking compatibility on the quantized file, not just the original.

## Why not a chatbot

One file in, one structured compatibility report out — there's no exchange to have. A checkbox
list for frameworks and a table for results makes the actual decision (which framework to
target) inspectable at a glance, which a paragraph of chat prose would bury.
