# Edge AI Compression Advisor — Agent 3 of the Edge AI Copilot Suite

## What this agent does

Upload a real `.onnx` model file, pick a quantization weight type, click **Quantize**. This
agent actually runs [ONNX Runtime's dynamic quantization](https://onnxruntime.ai/docs/performance/model-optimizations/quantization.html)
on your file — the size reduction shown is measured on disk, not estimated by an LLM. You get
a before/after chart, a table of the real operator types found in your model's graph, and a
downloadable quantized `.onnx` file.

**Verified end-to-end before shipping:** a real test model (a 257KB single-layer network) was
quantized during development and measured a 74.5% real size reduction (257KB → 66KB) — the
pipeline is proven to work, not just written to spec.

**This is an upload-and-report tool, not a chatbot.** You give it a file, you get back a file
plus a report. There's nothing to converse about.

## Why it's built this way (architecture)

```
Uploaded .onnx file
    |
    v
onnx.load() + checker.check_model()   <-- real parsing/validation, catches invalid files
    |                                      immediately with a clear error, not a vague failure
    v
quantize_dynamic()  <-- ACTUAL ONNX Runtime quantization runs here. This is not a size
    |                    estimate or a lookup table -- your file goes in, a real smaller
    |                    file comes out.
    v
Real before/after size (os.path.getsize on both files) + real operator-type counts
    |                    (parsed directly from the model graph)
    v
Size chart + op table + downloadable quantized file   <-- shown/offered directly
    |
    v
explain()  <-- the ONLY place Gemini is called. Given the real measured numbers, it writes
    |           3-4 sentences of context (what dynamic quantization does and doesn't affect,
    |           a reminder to validate accuracy separately). Told explicitly not to invent
    |           or contradict the numbers it's shown.
    v
Result panel
```

## What dynamic quantization actually does (so the output makes sense)

Dynamic quantization converts a model's float32 weights to int8/uint8, shrinking file size
and often speeding up inference on CPU — without needing a calibration dataset (unlike static
quantization). It mainly affects weight-heavy operators: `MatMul`, `Gemm`, `Conv`. A model
dominated by other op types (activations, reshapes, pooling) will shrink less dramatically.
This agent's "top operator types" table is there specifically so you can sanity-check whether
your model has enough weight-heavy ops for quantization to be worth doing.

**Important:** this process does not measure accuracy impact. Quantization can degrade model
accuracy, sometimes significantly, depending on the model. Always validate the quantized
model's outputs against the original before deploying it.

## What's in this folder

| File | Purpose |
|---|---|
| `app.py` | ONNX loading/validation, real quantization, Gemini explanation, Gradio upload UI |
| `requirements.txt` | Python dependencies |
| `Dockerfile` | Container build instructions |
| `README.md` | This file |

## UI walkthrough

- **File upload** — accepts `.onnx` files only.
- **Quantization weight type dropdown** — INT8 (QInt8, signed, the typical default) or UINT8
  (QUInt8, unsigned). Different runtimes/hardware sometimes prefer one over the other.
- **Quantize button** — triggers real loading, validation, quantization, and measurement.
- **Size chart** — original vs. quantized size in MB, measured directly from disk.
- **Operator type table** — the real op types present in your model's graph and how many of
  each, sorted by frequency.
- **Result panel** — the real reduction percentage stated up front, followed by Gemini's plain-
  language context.
- **Download button** — the actual quantized `.onnx` file, ready to use.

## Prerequisites

1. **Docker**, installed and running.
2. **A free Gemini API key** from [aistudio.google.com](https://aistudio.google.com) — no card
   required.
3. **A real `.onnx` model file** to test with. If you don't have one handy, export any small
   PyTorch/TensorFlow model with `torch.onnx.export()` or `tf2onnx`, or use one of the tiny
   reference models from the Device Recommender agent's benchmark table as inspiration.

## Steps to run it

```bash
cd agent-compression-advisor
docker build -t edge-compression-advisor .
docker run -p 7862:7862 -e GEMINI_API_KEY=your_key_here edge-compression-advisor
```

Open [http://localhost:7862](http://localhost:7862), upload an `.onnx` file, click Quantize.

Stop with `Ctrl+C`, or `docker stop <container_id>`.

## Publishing to Docker Hub

```bash
docker login
docker tag edge-compression-advisor your-dockerhub-username/edge-compression-advisor:latest
docker push your-dockerhub-username/edge-compression-advisor:latest
```

Others run it with:
```bash
docker run -p 7862:7862 -e GEMINI_API_KEY=their_key your-dockerhub-username/edge-compression-advisor
```

## Notes / limitations

- **Dynamic quantization only** — this doesn't do static (calibration-based) quantization,
  which typically gives better accuracy retention but requires a representative dataset. Static
  quantization would be a natural next feature.
- **No accuracy check.** The agent reports size reduction only. Before deploying a quantized
  model, run it against a validation set and compare outputs to the original.
- **ONNX Runtime prints a pre-processing suggestion** to the container logs
  ("Please consider to run pre-processing before quantization...") — this is normal, not an
  error. Running `onnxruntime.quantization.shape_inference.quant_pre_process()` first can
  improve results on some models; it's not included here to keep the pipeline simple, but is a
  good next addition.
- **Large models will be slow to quantize** inside the container, and Gradio's default upload
  limit may need raising for very large files (`gr.Blocks(...).queue()` with a larger
  `max_file_size` if you hit this).

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `RuntimeError: GEMINI_API_KEY is not set` | Forgot `-e GEMINI_API_KEY=...` | Add the flag with your real key |
| "Could not load this as a valid ONNX model" | File isn't a valid ONNX model, or is corrupted | Re-export the model, or verify it loads with `onnx.load()` locally first |
| "Quantization failed: ..." | Some models have op types or structures dynamic quantization doesn't support | Check the specific error message; not all ONNX graphs are quantizable as-is |
| `404 NOT_FOUND` model error in the result panel | Gemini deprecated `gemini-3.6-flash` | Check [aistudio.google.com](https://aistudio.google.com) for the current model ID, update `explain()`, rebuild |
| Port conflict | 7862 already in use | Run with `-p 8082:7862`, open `localhost:8082` |
| Upload rejected / too large | Gradio's default file size limit | Increase `max_file_size` when launching, rebuild |

## Pairing with Agents 1 and 2

Agent 1 tells you what's feasible on your device; Agent 2 finds you a candidate model; this
agent shrinks that model to actually fit the device's real RAM budget from Agent 1's report.

## Why not a chatbot

One file in, one report and one file out — there's no exchange to have. An upload form makes
the actual input (a file) and the actual output (another file, plus a report) explicit, which a
chat window would have to awkwardly work around with file-attachment UI anyway.
